package frsf.isi.died.app.controller;

public enum TiposAcciones {
	ABM_LIBROS,ABM_VIDEOS,VER_GRAFO, BUSQUEDA,VER_WISHLIST;
}
