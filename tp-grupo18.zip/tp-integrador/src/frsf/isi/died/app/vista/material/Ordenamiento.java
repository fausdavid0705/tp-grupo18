package frsf.isi.died.app.vista.material;

public enum Ordenamiento {
	Titulo,Calificacion,Precio,Fecha,Relevancia;
}
