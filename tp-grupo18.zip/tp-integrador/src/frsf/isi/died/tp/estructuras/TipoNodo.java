package frsf.isi.died.tp.estructuras;

public enum TipoNodo {
	TITULO,METADATO,AUTOR,SECCION,PARRAFO,CAPITULO,EDITORIAL,RESUMEN,PALABRA_CLAVE;
}
