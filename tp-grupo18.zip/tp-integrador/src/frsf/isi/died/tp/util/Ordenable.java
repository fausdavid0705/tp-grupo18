package frsf.isi.died.tp.util;

public interface Ordenable {

	public int valor();
}
